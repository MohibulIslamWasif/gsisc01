# School-Website [link](https://vishal5251.github.io/School-Website/);

The Main points that need to be provided in your School Website as per CBSE Circular/2013/572430 are :

 1. Name of the School with All Contact Information of the School
 2. Year of Establishment
 3. NOC No. Obtained from State Govt/ UI
 4. Recognition of School by Authority and Authority Name
 5. Status of Affiliation
 6. Name of Trust / Society / Company
 7. List of Members of School/ Managing Committee
 8. Name of Manger/ President/ Chairman/ Correspondent
 9. Area of School
10. Details of Fee
11. Transport Facility
12. Number of teaching Staff (To be updated on time to time)
13. Details of Salary Paid to Teaching/ Non Teaching Staff (To be updated on time to time)
14. Mode of Payment of Salary
15. Library Facilities
16. Name of the Grievance Redressal Officer with Email and Fax
17. Member of Sexual Harassment Committee
18. Class-wise Enrollment of School for the Current Session
19. Academic Session Period
20. Vacation Period
21. Admission Period

Some School Website Repositories :- https://github.com/MountSionCBSSecondary/SchoolWebsite.git


